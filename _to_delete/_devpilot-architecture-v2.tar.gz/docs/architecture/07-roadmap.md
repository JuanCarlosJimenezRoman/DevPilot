# 07 — Roadmap e incrementos (Fase J)

> **Revisado con Juan (2026-09-09).** Esta versión reemplaza el roadmap inicial: el Incremento 1 queda aún más angosto de lo propuesto originalmente — ni siquiera incluye Project Knowledge/Session Memory/Decision Records todavía — para poder validar la hipótesis central lo antes posible y con datos medibles, no solo con intuición.

Principio: cada incremento debe terminar en algo que se pueda ejecutar y probar de punta a punta. La hipótesis central que hay que probar primero, y de la que depende todo lo demás, es angosta y concreta:

```
Proyecto
 ↓
Contexto persistente (mínimo)
 ↓
Context Pack
 ↓
IA web (DeepSeek / Claude / ChatGPT)
 ↓
Respuesta
 ↓
Import (parser de 3 capas)
 ↓
Diff
 ↓
Apply
```

Si esta cadena funciona, el resto del roadmap es incrementar sofisticación sobre una base ya validada. Si no funciona, ninguna otra pieza (Git, Claude Code, memoria persistente) importa todavía.

## Paso 0 — Validación manual del contrato de respuesta (sin código)

Antes de escribir el Incremento 1: tomar una tarea real (ej. de "Camino al Deporte"), redactar a mano un Context Pack con las instrucciones de formato de 06 (bloques `<DEVPILOT_CHANGE>` + variante Markdown amigable), y pegarlo en DeepSeek Web y en Claude Web. Observar: ¿entienden el contexto?, ¿respetan el formato?, ¿las respuestas son interpretables?, ¿qué tan tolerante necesita ser el parser en la práctica? Esta prueba puede ahorrar bastante trabajo de diseño equivocado en el parser, y responde la pregunta más importante del proyecto: **¿una IA web gratuita/por suscripción puede funcionar como "cerebro externo" sin API?** Si la respuesta práctica es sí, la hipótesis fundamental de DevPilot queda validada.

## Incremento 0 — Andamiaje

- Monorepo pnpm (`apps/cli`, `packages/core`, `packages/storage`, `packages/shared`), TypeScript estricto, lint, build.
- `devpilot --version` funcionando end-to-end como humo del setup.

## Incremento 1 — "Proof of Context"

Objetivo único: demostrar la cadena completa Proyecto → Contexto → IA web → Respuesta → Import → Diff → Apply, con la menor cantidad de piezas posible.

- `devpilot project add <ruta>` → Scanner detecta stack (lenguaje/framework/package manager/Git presente) → Project Snapshot persistido (registro global en `~/.devpilot/` + estado local en `.devpilot/state/snapshot.json`, ver 03).
- `devpilot context "<tarea>"` → Context Planner **simple y medible, no "superinteligente"**: coincidencias de texto/nombre + imports directos + proximidad de rutas (Nivel 1 + Nivel 2 de 04, nada de AST ni Git todavía) → Relevance Scoring v1 con razones explicables → Token Estimate → Context Pack exportado a Markdown y JSON, **siempre persistido en `.devpilot/context/`** (nunca solo mostrado en pantalla — se audita después qué sabía la IA), y copiado al portapapeles.
- El usuario pega el pack en DeepSeek Web / Claude Web / ChatGPT, conversa, y copia la respuesta.
- `devpilot import <archivo-o-texto>` → parser de tres capas (06): reconoce varios formatos, marca confianza, nunca aplica en ambigüedad.
- `devpilot diff` → muestra diff de los cambios propuestos; para parches tipo SEARCH/REPLACE, valida que el fragmento SEARCH siga coincidiendo con el archivo actual antes de ofrecer aplicar.
- `devpilot apply` → aplica cambios uno por uno, con confirmación (Tool Engine, riesgo `WRITE`), registrado en `tool_invocations`.
- **Benchmark automático por tarea** (`task_benchmarks`, ver 03/04): tokens enviados, archivos incluidos vs. usados, cambios importados vs. aplicados, resultado. Esto es parte del Incremento 1, no un "nice to have" posterior — es como se mide si la hipótesis central realmente funciona.

Lo que **no** entra en el Incremento 1: Project Knowledge, Session Memory, Decision Records (pasan al Incremento 2), Git más allá de detectar que existe, símbolos/AST, Claude Code, análisis semántico.

**Criterio de éxito:** repetir el ejemplo "Camino al Deporte" — escribir una tarea, obtener un Context Pack razonable, pegarlo en un chat web real, pegar la respuesta de vuelta, y que DevPilot reconstruya el diff correctamente — con métricas de benchmark que respalden la afirmación de ahorro de contexto.

## Incremento 2 — "Project Memory"

- Project Knowledge (`knowledge_docs` + `.devpilot/knowledge/*.md`), inicialmente poblado por heurísticas del Scanner (`source: 'inferred'`) y editable a mano (`source: 'manual'`).
- Session Memory real (más allá de un log plano) y promoción de eventos de sesión relevantes.
- Decision Records (`devpilot decide "<título>"`).
- Refresco incremental de Project State.

## Incremento 3 — "Git Intelligence"

- `git status` / `git diff` / `git log` vía `GitAdapter` (02).
- Reindexado incremental basado en `lastIndexedCommit` + `git diff --name-status` (evita rescanear todo el árbol).
- Extracción de símbolos (AST ligero) → Nivel 3 del Context Planner.
- Nivel 4: boost de relevancia por recencia en Git y afinidad con mensajes de commit.
- Context Compaction para packs 🔴.

## Incremento 4 — "Claude Code"

- `devpilot analyze --deep` → `ClaudeCodeProvider` en modo de solo lectura/plan → propone contenido para `knowledge_docs` (arquitectura, módulos, reglas de negocio, decisiones detectadas) → el usuario aprueba el diff antes de escribir (mismo flujo de aprobación del Tool Engine).
- `lastDeepAnalysisCommit` para saber qué cambió desde el último análisis profundo.

## Incremento 5 — "Browser Bridge"

- `apps/browser-extension` con adapters específicos por sitio (`deepseek-web`, `claude-web`, `chatgpt-web`) que automatizan el copiar/pegar físico como conveniencia de UX. El parseo de respuesta sigue siendo el mismo contrato de tres capas de 06 — la extensión nunca es una dependencia funcional, solo ahorra clics.

## Más adelante (exploratorio)

- `devpilot analyze` con otros proveedores (DeepSeek API, OpenAI API) detrás de la misma interfaz `AIProvider`, siempre BYOAI.
- Desktop UI (Electron + React + Vite) como cliente fino de la API programática de `core`.
- Soporte multi-lenguaje más allá de TypeScript/JavaScript.
- Capa semántica local opcional (Nivel 5), solo si el benchmark del Incremento 1-3 demuestra que el scoring heurístico es insuficiente en la práctica.

---

**Siguiente paso concreto:** hacer el Paso 0 (validación manual, sin código) con una tarea real. Si el resultado es alentador, el primer código que escribimos es el Incremento 0 + el Scanner del Incremento 1.
