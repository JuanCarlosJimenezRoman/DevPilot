# 06 — Provider Architecture y Browser Bridge (Fases H, I)

## La interfaz `AIProvider`

La interfaz propuesta originalmente era un buen punto de partida pero le faltaba: detección de disponibilidad (¿está instalado/logueado?), cancelación real, y — clave para este proyecto — un provider que represente "un humano pegando en un chat web" como ciudadano de primera clase, no como caso especial.

```ts
interface ProviderCapabilities {
  streaming: boolean;
  toolCalling: boolean;
  requiresApiKey: boolean;
  costModel: 'none' | 'session-plan' | 'metered-api';  // ver nota sobre Claude Code abajo
  supportsSessions: boolean;
  supportsCancellation: boolean;
  maxContextTokens?: number;
}

interface AIRequest {
  sessionId?: string;
  prompt: string;
  contextPack?: ContextPack;
  systemInstructions?: string;
  tools?: ToolDefinition[];
  maxOutputTokens?: number;
  signal?: AbortSignal;
}

type AIEvent =
  | { type: 'text-delta'; text: string }
  | { type: 'tool-call'; name: string; params: unknown }
  | { type: 'tool-result'; name: string; result: unknown }
  | { type: 'error'; error: { message: string; retryable: boolean } }
  | { type: 'done'; usage?: { inputTokens?: number; outputTokens?: number } };

interface AIProvider {
  id: string;
  displayName: string;
  capabilities: ProviderCapabilities;
  isAvailable(): Promise<boolean>;      // feature-detection: ¿binario instalado?, ¿API key presente?
  execute(request: AIRequest): AsyncIterable<AIEvent>;
  cancel?(sessionId: string): Promise<void>;
}
```

## `ManualProvider` — el flujo "pegar en un chat web", formalizado

Este es el provider que hace que el flujo manual (DeepSeek web, Claude web, ChatGPT web) sea un ciudadano de primera clase del sistema, no un atajo fuera de la arquitectura:

- `execute()` no llama a ninguna IA. Renderiza el `ContextPack` a Markdown, lo copia al portapapeles, y emite `done` inmediatamente.
- La respuesta real de la IA llega más tarde, fuera de banda, vía `devpilot import <archivo-o-texto>`.
- `capabilities`: `streaming: false`, `toolCalling: false`, `requiresApiKey: false`.

Esto es deliberado: modelar el caso "sin automatización" como un provider más — no como una rama especial del código — es lo que mantiene el resto del sistema (Context Planner, Tool Engine, sesiones) idéntico sin importar si la IA fue Claude Code, DeepSeek web, o ChatGPT web.

## `ClaudeCodeProvider`

Invoca el binario `claude` instalado localmente vía subprocess, en modo no interactivo:

- Modo `--print`/`-p` con `--output-format stream-json` (o `json` si no se necesita streaming) para obtener salida estructurada y parseable, en vez de texto libre de terminal.
- `--permission-mode` restringido (ej. modo de solo lectura/plan) cuando se usa para `analyze --deep`, ya que el objetivo es que Claude Code *proponga* conocimiento, no que edite archivos directamente sin pasar por el Tool Engine de DevPilot.
- `isAvailable()` verifica que el binario exista en PATH y que haya una sesión válida (ej. `claude --version` o un comando de status), sin fallar el resto de DevPilot si no lo hay.
- Manejo de errores: proceso no encontrado, timeout, salida no parseable, exit code distinto de cero — todos se mapean a eventos `{ type: 'error' }`, nunca excepciones no controladas que tumben el CLI de DevPilot.
- `capabilities`: `toolCalling: true` (Claude Code tiene sus propias herramientas), `requiresApiKey: false`, `costModel: 'session-plan'` (**confirmado con Juan**: usa la sesión/suscripción existente del usuario, no una API pagada por llamada — pero **no es gratis ni ilimitado**, está sujeto a los límites de uso del plan del usuario. El producto nunca debe presentarlo como "IA gratis"; la UI del CLI debe reflejar `costModel` para que el usuario sepa qué está usando), `supportsCancellation: true` (kill del subprocess).

Nota de robustez: los flags exactos del CLI de Claude Code pueden cambiar entre versiones. `ClaudeCodeProvider` debe versionar/validar la salida esperada y fallar de forma explícita y legible (no silenciosa) si el formato cambió, en vez de asumir compatibilidad ciega.

## Providers futuros (no en v1, mismo contrato)

`DeepSeekApiProvider`, `OpenAiApiProvider`: adaptadores HTTP delgados sobre la misma interfaz `AIProvider`, `requiresApiKey: true`, la key vive en `config.json` o variables de entorno del usuario — nunca en el repo. `LocalAiProvider` (Ollama u otro): mismo contrato, `requiresApiKey: false`. Ninguno de estos requiere cambios en Context Engine, Tool Engine o CLI — es exactamente el punto de la abstracción.

## Browser Bridge — arquitectura agnóstica de sitio

La idea original de "no depender del HTML de un sitio específico" es correcta y se resuelve con una observación clave: **el Browser Bridge no necesita saber en qué sitio web estuvo el usuario.** Lo único que necesita es (a) darle al usuario el Context Pack en un formato fácil de pegar, y (b) parsear la respuesta cruda de texto que el usuario pegue de vuelta — y ese parseo depende del **contrato de formato de respuesta** que ya viaja dentro del propio Context Pack (ver 01 y 04), no del sitio de origen.

```ts
interface BrowserBridgeAdapter {
  id: string;                                    // 'clipboard-generic' | 'deepseek-web' | 'claude-web' | ...
  prepareTransfer(pack: ContextPack): TransferPayload;
  parseResponse(raw: string): ParsedResponse;
}

interface TransferPayload {
  text: string;              // Markdown listo para copiar
  copiedToClipboard: boolean;
}

interface ParsedResponse {
  changes: FileChangeProposal[];
  unparsedNotes: string;     // texto que no se pudo mapear a un cambio de archivo, mostrado al usuario tal cual, nunca descartado
}

interface FileChangeProposal {
  path: string;
  operation: 'create' | 'edit' | 'delete' | 'patch';
  format: 'devpilot-block' | 'json' | 'markdown-file' | 'diff' | 'fence-only';
  confidence: 'high' | 'low' | 'ambiguous';
  newContent?: string;        // para create/edit de archivo completo
  diff?: string;               // si la IA respondió en diff unificado
  patch?: SearchReplacePatch;  // para operation='patch' — ver contrato abajo
}

interface SearchReplacePatch {
  search: string;             // fragmento que la IA afirma que existe en el archivo actual
  replace: string;
  searchMatched?: boolean;    // se completa en tiempo de diff: ¿el fragmento SEARCH sigue existiendo tal cual en el archivo?
}
```

**V1 implementa únicamente `ClipboardGenericAdapter`**: funciona igual sin importar si el usuario usó DeepSeek, Claude o ChatGPT, porque no automatiza nada del sitio — copia el pack, y luego parsea lo que el usuario pegue de vuelta según el contrato de formato. Los adapters específicos de sitio (`deepseek-web`, `claude-web`, ...) quedan reservados para una futura extensión de navegador cuya única función sería automatizar el copiar/pegar físico (UX), nunca el parseo — el parseo siempre es responsabilidad del contrato de formato, no del sitio. Esto es justo lo que evita el acoplamiento fràgil que la propuesta original quería evitar.

### El contrato de formato de respuesta — diseño de tres capas (revisado con Juan, crítico, ver 01)

No confiamos en que DeepSeek, Claude o ChatGPT obedezcan un formato rígido de forma perfecta y consistente — pero un parser demasiado permisivo puede aplicar cambios incorrectos sin que el usuario lo note. La solución no es un formato único, son tres capas independientes.

**Capa 1 — Formato recomendado en `responseInstructions`.** El Context Pack le pide a la IA responder con bloques estructurados y, cuando el cambio es un fragmento localizado (no un archivo nuevo), con un patch de tipo búsqueda/reemplazo en vez del archivo completo — así la IA no tiene que reescribir archivos grandes enteros, y DevPilot puede verificar antes de aplicar:

```
<DEVPILOT_CHANGE path="src/services/shipping.ts" operation="patch">
<<<<<<< SEARCH
const shippingCost = 200;
=======
const shippingCost = calculateShipping(destino);
>>>>>>> REPLACE
</DEVPILOT_CHANGE>
```

También se acepta una variante más amigable para modelos que prefieren Markdown estándar (encabezado `### File: <ruta>` seguido de un fence ```diff o del archivo completo). Ambas formas son "recomendadas"; ninguna es obligatoria — ver Capa 2.

**Capa 2 — Parser tolerante.** `ClipboardGenericAdapter.parseResponse()` intenta reconocer, en este orden, varios formatos conocidos antes de rendirse: bloques `<DEVPILOT_CHANGE>`, JSON explícito, Markdown con encabezado de archivo, diff unificado estándar, y como último recurso un fence de código genérico cuya primera línea sea una ruta válida del proyecto. Cada `FileChangeProposal` detectado registra qué formato lo produjo (`format`) y con qué confianza (`confidence`). Texto que no calza con ningún patrón (ej. "Claro, aquí está el código...") no rompe nada — se acumula en `unparsedNotes` y se muestra tal cual.

**Capa 3 — Nunca aplicar automáticamente si hay ambigüedad.** Si `confidence` es `'low'` o `'ambiguous'` para un cambio, o si `operation='patch'` y `searchMatched === false` (el fragmento SEARCH ya no coincide con el archivo actual — típicamente porque el archivo cambió después de generar el Context Pack), DevPilot **no toca el proyecto**: muestra "⚠️ No pude interpretar/aplicar con seguridad este cambio" junto con la respuesta cruda, y requiere que el usuario decida manualmente. Esto es lo mismo que ya exige el Tool Engine para cualquier `WRITE` (05) — aquí se suma una verificación adicional específica de parches antes de siquiera llegar al paso de aprobación.

La verificación de `searchMatched` es intencionalmente simple: una comparación exacta del fragmento `SEARCH` contra el contenido actual del archivo. Es justo la protección que evita el problema común de agentes de código que aplican un patch calculado sobre una versión del archivo que ya no existe.

**Esto sigue siendo el supuesto que hay que probar con un caso real (ej. una tarea de "Camino al Deporte" contra DeepSeek Web y Claude Web) antes de construir el resto del pipeline de import/diff/apply** — sin necesidad de programar nada todavía: basta con redactar el Context Pack con estas instrucciones y observar qué tan bien lo respetan los modelos en la práctica (ver 01).
