# 03 — Modelo de datos SQLite (Fase C)

## Principio de diseño

SQLite guarda **metadata consultable** (índices, referencias, estado, bitácora). El **contenido largo** (conocimiento del proyecto, context packs, logs de sesión) vive como archivos Markdown/JSON en `.devpilot/`, y la fila en SQLite solo apunta a esa ruta. Esto mantiene la base de datos pequeña, rápida, y hace que el contenido importante sea legible/versionable con Git si el usuario decide commitear `.devpilot/` (opcional, decisión del usuario).

## Dos bases de datos, no una

- **Registro global** — `~/.devpilot/registry.db`: qué proyectos existen y dónde. Necesario porque `devpilot project add` implica que DevPilot conoce múltiples proyectos, no solo el directorio actual (como sí hace Git con `.git/`).
- **Base por proyecto** — `<proyecto>/.devpilot/devpilot.db`: todo lo específico de ese proyecto. Portátil: si el usuario mueve o comparte la carpeta del proyecto (o la excluye de Git vía `.gitignore`), su estado va con ella.

## Registro global (`~/.devpilot/registry.db`)

```sql
CREATE TABLE projects (
  id            TEXT PRIMARY KEY,        -- uuid
  name          TEXT NOT NULL,
  root_path     TEXT NOT NULL UNIQUE,
  created_at    TEXT NOT NULL,
  last_opened_at TEXT
);
```

## Base por proyecto (`.devpilot/devpilot.db`)

```sql
-- Estado general del proyecto (fila única, o clave/valor genérica)
CREATE TABLE project_state (
  project_id              TEXT PRIMARY KEY,
  last_indexed_commit     TEXT,
  last_deep_analysis_commit TEXT,
  last_scan_at            TEXT,
  snapshot_version        INTEGER NOT NULL DEFAULT 0,
  snapshot_path           TEXT              -- .devpilot/state/snapshot.json
);

-- Índice de archivos
CREATE TABLE files (
  id                TEXT PRIMARY KEY,
  path              TEXT NOT NULL UNIQUE,   -- relativo al root del proyecto
  hash              TEXT NOT NULL,          -- sha256 del contenido
  language          TEXT,
  size_bytes        INTEGER,
  last_modified     TEXT,
  last_seen_commit  TEXT,
  indexed_at        TEXT NOT NULL
);
CREATE INDEX idx_files_path ON files(path);

-- Grafo de imports/dependencias (incremento 2, tabla existe desde v1 para no migrar después)
CREATE TABLE file_edges (
  id            TEXT PRIMARY KEY,
  from_file_id  TEXT NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  to_file_id    TEXT NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  kind          TEXT NOT NULL DEFAULT 'import'   -- 'import' | 'test-of' | ...
);
CREATE INDEX idx_edges_from ON file_edges(from_file_id);
CREATE INDEX idx_edges_to   ON file_edges(to_file_id);

-- Símbolos (funciones/clases/exports) — poblada desde incremento 2
CREATE TABLE symbols (
  id          TEXT PRIMARY KEY,
  file_id     TEXT NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  name        TEXT NOT NULL,
  kind        TEXT NOT NULL,        -- 'function' | 'class' | 'interface' | 'const' | ...
  line_start  INTEGER,
  line_end    INTEGER,
  is_exported INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX idx_symbols_name ON symbols(name);
CREATE INDEX idx_symbols_file ON symbols(file_id);

-- Índice de Project Knowledge (el contenido vive en .devpilot/knowledge/*.md)
CREATE TABLE knowledge_docs (
  id           TEXT PRIMARY KEY,
  type         TEXT NOT NULL,       -- 'architecture' | 'modules' | 'database' | 'business-rules' | 'conventions' | 'custom'
  title        TEXT NOT NULL,
  path         TEXT NOT NULL,       -- .devpilot/knowledge/<slug>.md
  content_hash TEXT NOT NULL,
  source       TEXT NOT NULL,       -- 'manual' | 'deep-analysis' | 'inferred'
  updated_at   TEXT NOT NULL
);

-- Decision Records
CREATE TABLE decisions (
  id             TEXT PRIMARY KEY,
  title          TEXT NOT NULL,
  context        TEXT NOT NULL,
  decision       TEXT NOT NULL,
  consequences   TEXT,
  status         TEXT NOT NULL DEFAULT 'accepted',  -- 'proposed' | 'accepted' | 'superseded'
  related_files  TEXT,              -- json array
  tags           TEXT,              -- json array
  created_at     TEXT NOT NULL
);

-- Sesiones (el detalle turno-a-turno vive en .devpilot/sessions/<id>.jsonl)
CREATE TABLE sessions (
  id             TEXT PRIMARY KEY,
  started_at     TEXT NOT NULL,
  ended_at       TEXT,
  task_summary   TEXT,
  provider_used  TEXT,
  events_path    TEXT               -- .devpilot/sessions/<id>.jsonl
);

-- Context Packs generados (el contenido vive en .devpilot/packs/<id>.md + .json)
CREATE TABLE context_packs (
  id              TEXT PRIMARY KEY,
  session_id      TEXT REFERENCES sessions(id) ON DELETE SET NULL,
  task_text       TEXT NOT NULL,
  created_at      TEXT NOT NULL,
  token_estimate  INTEGER,
  classification  TEXT,             -- 'green' | 'yellow' | 'red'
  markdown_path   TEXT NOT NULL,
  json_path       TEXT NOT NULL
);

-- Bitácora de auditoría de herramientas (todo lo que pasó por el Tool Engine)
CREATE TABLE tool_invocations (
  id             TEXT PRIMARY KEY,
  session_id     TEXT REFERENCES sessions(id) ON DELETE SET NULL,
  tool_name      TEXT NOT NULL,
  risk_level     TEXT NOT NULL,     -- 'read' | 'write' | 'delete' | 'terminal' | 'git-commit'
  params_json    TEXT NOT NULL,
  approved       INTEGER NOT NULL DEFAULT 0,
  approved_at    TEXT,
  result_summary TEXT,
  created_at     TEXT NOT NULL
);
CREATE INDEX idx_invocations_session ON tool_invocations(session_id);

-- Cache de relevancia (opcional, evita recalcular para la misma tarea)
CREATE TABLE relevance_cache (
  id           TEXT PRIMARY KEY,
  task_hash    TEXT NOT NULL,
  file_id      TEXT NOT NULL REFERENCES files(id) ON DELETE CASCADE,
  score        REAL NOT NULL,
  reasons_json TEXT NOT NULL,
  computed_at  TEXT NOT NULL
);
CREATE INDEX idx_relevance_task ON relevance_cache(task_hash);
```

## Layout de `.devpilot/` en disco

```
<proyecto>/.devpilot/
├── devpilot.db
├── knowledge/
│   ├── architecture.md
│   ├── modules.md
│   ├── database.md
│   ├── business-rules.md
│   └── conventions.md
├── state/
│   └── snapshot.json
├── decisions/            # opcional: espejo legible de la tabla `decisions` en Markdown, uno por decisión
├── sessions/
│   └── <session-id>.jsonl
├── packs/
│   ├── <pack-id>.md
│   └── <pack-id>.json
└── config.json            # allowlist de comandos, pesos del relevance scorer, límites de tokens, etc.
```

`config.json` es donde vive todo lo que el usuario puede querer ajustar sin tocar código: pesos del scorer, comandos de terminal permitidos por defecto, umbrales de clasificación de tokens (verde/amarillo/rojo) — para no hardcodear esos números en el core.
