# 07 — Roadmap e incrementos (Fase J)

Principio: cada incremento debe terminar en algo que se pueda ejecutar y probar de punta a punta, no en "medio módulo". El flujo de 20 pasos de la propuesta original es la visión correcta a mediano plazo, pero como *primer* incremento incluye demasiado (Git incremental, símbolos AST, Claude Code, compactación) para validar la hipótesis central con rapidez. La hipótesis central que hay que probar primero es mucho más angosta: **¿un Context Pack generado sin IA es lo bastante bueno como para que pegarlo en un chat web ahorre tiempo real, y puede DevPilot reconstruir cambios de archivo a partir de la respuesta?**

## Incremento 0 — Andamiaje

- Monorepo pnpm (`apps/cli`, `packages/core`, `packages/storage`, `packages/shared`), TypeScript estricto, lint, build.
- `devpilot --version` funcionando end-to-end como humo del setup.

## Incremento 1 — El primer flujo funcional real (el que hay que demostrar)

- `devpilot project add <ruta>` → Scanner detecta stack (lenguaje/framework/package manager/Git presente) → Project Snapshot persistido en SQLite + `.devpilot/state/snapshot.json`.
- `devpilot context "<tarea>"` → Context Planner **solo Nivel 1 + Nivel 2** (texto + imports, sin AST, sin Git recency todavía) → Relevance Scoring v1 → Token Estimate → Context Pack en Markdown, guardado en `.devpilot/packs/` y copiado al portapapeles.
- `devpilot import <archivo-o-texto>` → parsea la respuesta según el contrato de formato (06) → muestra los cambios detectados y el `unparsedNotes` si algo no calzó.
- `devpilot diff` → muestra diff de los cambios propuestos contra el estado actual de cada archivo.
- `devpilot apply` → aplica cambios uno por uno, con confirmación (Tool Engine, riesgo `WRITE`), registrado en `tool_invocations`.
- `devpilot decide "<título>"` → crea una Decision Record manualmente.

Este incremento **no toca Git más allá de detectar que existe**, no usa Claude Code, no hace análisis semántico. Es deliberadamente angosto para validar rápido si el contrato de formato de respuesta (el riesgo más grande identificado en 01) funciona en la práctica con DeepSeek/Claude/ChatGPT web reales.

**Criterio de éxito:** poder repetir el ejemplo "Camino al Deporte" del documento original — escribir una tarea, obtener un Context Pack razonable, pegarlo en un chat web real, pegar la respuesta de vuelta, y que DevPilot reconstruya el diff correctamente — al menos en un proyecto TypeScript/Next.js real tuyo.

## Incremento 2 — Contexto más inteligente y Git

- Reindexado incremental basado en `lastIndexedCommit` + `git diff --name-status`.
- Extracción real de símbolos (AST ligero, ej. vía un lexer/parser TS) → Nivel 3 del Context Planner.
- Nivel 4: boost de relevancia por recencia en Git (archivos y mensajes de commit).
- Context Compaction (excluir/truncar archivos de score bajo cuando el pack es 🔴).

## Incremento 3 — Claude Code para análisis profundo

- `devpilot analyze --deep` → `ClaudeCodeProvider` en modo de solo lectura/plan → propone contenido para `knowledge_docs` (arquitectura, módulos, reglas de negocio) → el usuario aprueba el diff antes de que se escriba (mismo Tool Engine, mismo flujo de aprobación que cualquier `WRITE`).
- `lastDeepAnalysisCommit` para saber qué cambió desde el último análisis profundo y no repetir trabajo.

## Incremento 4 — Más proveedores

- `DeepSeekApiProvider` / `OpenAiApiProvider` detrás de la misma interfaz `AIProvider`, opt-in, con API key del propio usuario (BYOAI, nunca obligatorio).
- Nivel 5 del Context Planner (semántico opcional) usando cualquier provider ya configurado, sobre un candidate set ya acotado.

## Incremento 5 — Desktop UI

- `apps/desktop` (Electron + React + Vite) como cliente fino de la API programática de `core` — sin lógica de negocio propia, tal como se definió en 02.

## Incremento 6 — Browser extension (conveniencia, no requisito)

- `apps/browser-extension` con adapters específicos por sitio (`deepseek-web`, `claude-web`, `chatgpt-web`) que automatizan el copiar/pegar físico. El parseo de respuesta sigue siendo el mismo contrato de formato de 06 — la extensión es puramente UX, nunca una dependencia funcional.

## Incremento 7+ (exploratorio, sin comprometerse aún)

- Soporte multi-lenguaje más allá de TypeScript/JavaScript.
- Capa semántica local opcional (embeddings locales, sin servicio cloud) si el scoring heurístico demuestra ser insuficiente en la práctica.

---

**Siguiente paso concreto:** si estás de acuerdo con este recorte, el primer código que escribimos es el Incremento 0 + el Scanner del Incremento 1. Antes de eso, vale la pena que confirmes los supuestos abiertos listados en 01 (especialmente el contrato de formato de respuesta) porque cambian el diseño del parser de `devpilot import`.
