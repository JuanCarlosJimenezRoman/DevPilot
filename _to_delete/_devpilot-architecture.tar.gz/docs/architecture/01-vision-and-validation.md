# 01 — Visión y validación crítica (Fase A)

## El problema real

Hoy, cuando cambias de IA (Claude Code → ChatGPT web → DeepSeek web), pierdes contexto. Cada herramienta reconstruye por su cuenta "qué es este proyecto", y tú pagas ese costo dos veces: en tokens (si usas API) y en tiempo (si lo explicas a mano). DevPilot ataca esto poniendo la memoria y el contexto *fuera* de la IA, en una capa local que cualquier modelo puede consumir.

Esto es un problema real y la propuesta original lo diagnostica bien. La idea central — **"la IA no debe ser la memoria del proyecto, DevPilot debe serlo"** — es la decisión de diseño correcta y todo lo demás debe subordinarse a ella.

## Qué está bien (y no debe negociarse)

- **Local-first.** Nada de esto necesita un servidor. Correcto para v1 y probablemente para siempre en el core.
- **Provider-agnostic + BYOAI.** Es el diferenciador real. Nadie más está construyendo "memoria de proyecto reutilizable entre ChatGPT web, Claude web y DeepSeek web sin automatizar el navegador".
- **Separar tipos de memoria** (Project Knowledge / Project State / Session Memory / Decision Records / Task Context). Esto imita cómo un ingeniero senior organiza el contexto mentalmente. Es una base sólida y NO la simplificaría.
- **Niveles progresivos de contexto** (texto → imports → símbolos → git → semántico opcional). Evita depender de embeddings desde el día uno. Correcto.
- **SQLite + archivos planos**, en vez de una sola base de datos monolítica para todo. Correcto: SQLite para metadata consultable, Markdown/JSON en disco para contenido largo y legible por humanos (y por Git).
- **Reglas anti-sobreingeniería** (nada de vector DB, cloud, k8s, multi-agente complejo en v1). Esto es disciplina, no debe aflojarse.

## Qué es innecesario o debe recortarse para v1

El documento original mezcla **visión del producto** (correcta, a 12-18 meses) con **alcance de v1** (que tal como está descrito es en realidad un v2/v3). Señalo específicamente:

- **Análisis AST/símbolos multi-lenguaje** (Nivel 3) es un proyecto en sí mismo. V1 debe limitarse a TypeScript/JavaScript (que es tu stack real hoy) con extracción de imports por regex/lexer ligero, no un parser AST completo. Symbols de verdad (funciones, clases, exports) puede vivir en incremento 2, no en el primer corte.
- **Cuatro formatos de Context Pack** (clipboard, Markdown, texto, JSON) es redundancia. Ver decisión abajo: solo necesitas un formato canónico interno + un renderer de exportación.
- **Analyze --deep con Claude Code** es valioso pero no debe estar en el primer incremento: agrega una dependencia externa (el CLI de Claude Code) al flujo crítico antes de que el flujo crítico exista.
- **Desktop UI / Electron / Browser Extension** — ya están correctamente pospuestos en el documento original. Lo confirmo: no tocarlos hasta que el CLI funcione end-to-end.
- **Estructura de monorepo completa desde el día 1** (`apps/desktop`, `apps/browser-extension`, `packages/providers`, `packages/context`, `packages/tools`, `packages/browser`, todos como paquetes pnpm separados desde el commit inicial) es fricción prematura: cada paquete nuevo son tsconfig, build, tests y versión propios. Recomiendo empezar con 3 paquetes reales (`core`, `storage`, `shared`) + `apps/cli`, y fragmentar `core` en paquetes nuevos únicamente cuando de verdad duela mantenerlo junto (por ejemplo, cuando aparezca el segundo provider o la segunda UI). El diseño en 02 explica exactamente dónde están esas costuras para que separar después sea barato.

## Qué es riesgoso (y cómo se mitiga)

1. **"Importar la respuesta de la IA" es el punto más frágil de todo el sistema.** Un modelo puede responder con código en cualquier formato: bloques con o sin ruta de archivo, diffs unificados, texto libre mezclado con explicaciones. Si DevPilot intenta "adivinar" el formato, va a fallar constantemente.
   **Mitigación:** el propio Context Pack incluye siempre una sección de instrucciones que le dice a la IA exactamente cómo debe formatear su respuesta (ej. bloques de código con la ruta del archivo como primer comentario, o diff unificado). El parser de importación no adivina: solo entiende ese contrato. Si el usuario pega algo que no lo respeta, DevPilot debe decirlo claramente y no intentar magia. Esto es supuesto **crítico a validar contigo con un prototipo real antes de invertir en el resto del pipeline.**

2. **`run_command` (terminal) es la herramienta más peligrosa del sistema.** Un "aprobar/no aprobar" genérico no es suficiente si el comando puede ser `rm -rf` o similar.
   **Mitigación:** en v1, mostrar el comando exacto, pedir confirmación explícita siempre (sin bypass por defecto), y opcionalmente una lista de comandos permitidos/bloqueados configurable por proyecto. Ver 05.

3. **Relevance scoring sin IA puede dar falsos negativos** (archivos relevantes con score bajo porque no comparten texto/nombre). No es resoluble al 100% con heurísticas, y no pasa nada: por eso existe el Nivel 5 (semántico opcional) y por eso el usuario siempre puede añadir archivos manualmente al Context Pack. No prometas precisión perfecta; expón el "por qué" de cada score (ver 04) para que el usuario pueda corregir.

4. **Claude Code como dependencia "opcional pero clave".** Claude Code es en sí un producto en evolución (flags, formatos de salida, políticas de permisos pueden cambiar). Aislarlo completamente detrás de la interfaz `AIProvider` (06) para que un cambio en el CLI de Claude Code no toque el resto del sistema.

## Supuestos que hay que validar antes de programar

Estos no los puedo resolver solo con diseño — necesitan una prueba rápida contigo:

- **¿"no depender de ninguna API" incluye a Claude Code?** Asumo que no: Claude Code usa tu sesión/suscripción existente, no una API key nueva pagada por llamada. Confírmalo, porque cambia si `ClaudeCodeProvider` es "gratis" o "con costo" desde la perspectiva del usuario.
- **¿DevPilot es multi-proyecto desde el día 1?** `devpilot project add` implica un registro global de proyectos (como Git conoce repos, pero DevPilot no tiene ese concepto nativo). Asumo que sí: existe un registro liviano en `~/.devpilot/` además del estado local en `<proyecto>/.devpilot/`. Ver 03.
- **¿Qué tan estricto debe ser el contrato de respuesta de la IA?** Necesito que probemos pegar una tarea real (como el ejemplo de "Camino al Deporte") en DeepSeek web o Claude web con las instrucciones de formato propuestas, y ver si el modelo las respeta de forma consistente. Si no, el diseño del parser de 06 debe endurecerse (por ejemplo exigiendo un bloque `<<<DEVPILOT_CHANGE path="...">>>`) en vez de confiar en fences de Markdown genéricos.
- **¿Vale la pena que el primer incremento incluya Git en absoluto?** Propongo que no (ver 07): el Nivel 4 (Git) puede esperar al incremento 2 sin romper el valor central del producto (contexto + transferencia entre IAs).

## Formato canónico del Context Pack — decisión

La propuesta original pregunta si hacen falta los cuatro formatos (clipboard, Markdown, texto plano, JSON). Mi recomendación:

- **Canónico interno:** un objeto TypeScript tipado (validado con `zod`), nunca texto. Es lo único que el Context Planner, el compactador y los tests deben conocer.
- **JSON:** serialización de ese objeto para persistencia (`.devpilot/packs/<id>.json`), debugging, y como base para una futura API. No es para pegar en un chat.
- **Markdown:** el único formato de exportación para humanos/IA en v1. Se copia al portapapeles directamente. Un chat web pega Markdown como texto plano sin problema — no gana nada tener un "texto plano" separado, así que **se elimina como formato independiente** (si hace falta alguna vez, es un `stripMarkdown(markdown)` de una línea, no un renderer nuevo).

Esto simplifica el `ContextPackRenderer` a dos funciones: `toJSON()` y `toMarkdown()`.
