# 06 — Provider Architecture y Browser Bridge (Fases H, I)

## La interfaz `AIProvider`

La interfaz propuesta originalmente era un buen punto de partida pero le faltaba: detección de disponibilidad (¿está instalado/logueado?), cancelación real, y — clave para este proyecto — un provider que represente "un humano pegando en un chat web" como ciudadano de primera clase, no como caso especial.

```ts
interface ProviderCapabilities {
  streaming: boolean;
  toolCalling: boolean;
  requiresApiKey: boolean;
  supportsSessions: boolean;
  supportsCancellation: boolean;
  maxContextTokens?: number;
}

interface AIRequest {
  sessionId?: string;
  prompt: string;
  contextPack?: ContextPack;
  systemInstructions?: string;
  tools?: ToolDefinition[];
  maxOutputTokens?: number;
  signal?: AbortSignal;
}

type AIEvent =
  | { type: 'text-delta'; text: string }
  | { type: 'tool-call'; name: string; params: unknown }
  | { type: 'tool-result'; name: string; result: unknown }
  | { type: 'error'; error: { message: string; retryable: boolean } }
  | { type: 'done'; usage?: { inputTokens?: number; outputTokens?: number } };

interface AIProvider {
  id: string;
  displayName: string;
  capabilities: ProviderCapabilities;
  isAvailable(): Promise<boolean>;      // feature-detection: ¿binario instalado?, ¿API key presente?
  execute(request: AIRequest): AsyncIterable<AIEvent>;
  cancel?(sessionId: string): Promise<void>;
}
```

## `ManualProvider` — el flujo "pegar en un chat web", formalizado

Este es el provider que hace que el flujo manual (DeepSeek web, Claude web, ChatGPT web) sea un ciudadano de primera clase del sistema, no un atajo fuera de la arquitectura:

- `execute()` no llama a ninguna IA. Renderiza el `ContextPack` a Markdown, lo copia al portapapeles, y emite `done` inmediatamente.
- La respuesta real de la IA llega más tarde, fuera de banda, vía `devpilot import <archivo-o-texto>`.
- `capabilities`: `streaming: false`, `toolCalling: false`, `requiresApiKey: false`.

Esto es deliberado: modelar el caso "sin automatización" como un provider más — no como una rama especial del código — es lo que mantiene el resto del sistema (Context Planner, Tool Engine, sesiones) idéntico sin importar si la IA fue Claude Code, DeepSeek web, o ChatGPT web.

## `ClaudeCodeProvider`

Invoca el binario `claude` instalado localmente vía subprocess, en modo no interactivo:

- Modo `--print`/`-p` con `--output-format stream-json` (o `json` si no se necesita streaming) para obtener salida estructurada y parseable, en vez de texto libre de terminal.
- `--permission-mode` restringido (ej. modo de solo lectura/plan) cuando se usa para `analyze --deep`, ya que el objetivo es que Claude Code *proponga* conocimiento, no que edite archivos directamente sin pasar por el Tool Engine de DevPilot.
- `isAvailable()` verifica que el binario exista en PATH y que haya una sesión válida (ej. `claude --version` o un comando de status), sin fallar el resto de DevPilot si no lo hay.
- Manejo de errores: proceso no encontrado, timeout, salida no parseable, exit code distinto de cero — todos se mapean a eventos `{ type: 'error' }`, nunca excepciones no controladas que tumben el CLI de DevPilot.
- `capabilities`: `toolCalling: true` (Claude Code tiene sus propias herramientas), `requiresApiKey: false` (usa la sesión/suscripción existente del usuario — **supuesto a confirmar contigo**, ver 01), `supportsCancellation: true` (kill del subprocess).

Nota de robustez: los flags exactos del CLI de Claude Code pueden cambiar entre versiones. `ClaudeCodeProvider` debe versionar/validar la salida esperada y fallar de forma explícita y legible (no silenciosa) si el formato cambió, en vez de asumir compatibilidad ciega.

## Providers futuros (no en v1, mismo contrato)

`DeepSeekApiProvider`, `OpenAiApiProvider`: adaptadores HTTP delgados sobre la misma interfaz `AIProvider`, `requiresApiKey: true`, la key vive en `config.json` o variables de entorno del usuario — nunca en el repo. `LocalAiProvider` (Ollama u otro): mismo contrato, `requiresApiKey: false`. Ninguno de estos requiere cambios en Context Engine, Tool Engine o CLI — es exactamente el punto de la abstracción.

## Browser Bridge — arquitectura agnóstica de sitio

La idea original de "no depender del HTML de un sitio específico" es correcta y se resuelve con una observación clave: **el Browser Bridge no necesita saber en qué sitio web estuvo el usuario.** Lo único que necesita es (a) darle al usuario el Context Pack en un formato fácil de pegar, y (b) parsear la respuesta cruda de texto que el usuario pegue de vuelta — y ese parseo depende del **contrato de formato de respuesta** que ya viaja dentro del propio Context Pack (ver 01 y 04), no del sitio de origen.

```ts
interface BrowserBridgeAdapter {
  id: string;                                    // 'clipboard-generic' | 'deepseek-web' | 'claude-web' | ...
  prepareTransfer(pack: ContextPack): TransferPayload;
  parseResponse(raw: string): ParsedResponse;
}

interface TransferPayload {
  text: string;              // Markdown listo para copiar
  copiedToClipboard: boolean;
}

interface ParsedResponse {
  changes: FileChangeProposal[];
  unparsedNotes: string;     // texto que no se pudo mapear a un cambio de archivo, mostrado al usuario tal cual
}

interface FileChangeProposal {
  path: string;
  kind: 'create' | 'edit' | 'delete';
  newContent?: string;       // para create/edit
  diff?: string;             // si la IA respondió en formato diff unificado
}
```

**V1 implementa únicamente `ClipboardGenericAdapter`**: funciona igual sin importar si el usuario usó DeepSeek, Claude o ChatGPT, porque no automatiza nada del sitio — copia el pack, y luego parsea lo que el usuario pegue de vuelta según el contrato de formato. Los adapters específicos de sitio (`deepseek-web`, `claude-web`, ...) quedan reservados para una futura extensión de navegador cuya única función sería automatizar el copiar/pegar físico (UX), nunca el parseo — el parseo siempre es responsabilidad del contrato de formato, no del sitio. Esto es justo lo que evita el acoplamiento fràgil que la propuesta original quería evitar.

### El contrato de formato de respuesta (crítico, ver 01)

Toda `ContextPack.responseInstructions` incluye algo equivalente a:

```
Responde tus cambios de código usando exactamente este formato por archivo:

```path/al/archivo.ts
<contenido completo del archivo o diff unificado>
```

No mezcles explicación dentro del bloque de código. Cualquier explicación va fuera del bloque.
```

`ClipboardGenericAdapter.parseResponse()` solo entiende bloques de código cuya primera línea (el "lenguaje" del fence en Markdown) es una ruta de archivo válida dentro del proyecto. Todo lo que no calce con ese patrón se devuelve como `unparsedNotes`, visible al usuario, nunca descartado silenciosamente ni aplicado a ciegas.

**Esto es exactamente el supuesto que hay que probar con un caso real antes de construir el resto del pipeline de import/diff/apply** (ver 01).
