# 04 — Context Engine en detalle (Fase F)

## Scanner

Recorre el árbol de archivos respetando `.gitignore` y un `.devpilotignore` adicional. Para cada archivo detecta lenguaje por extensión. A nivel de proyecto detecta, por heurísticas sobre archivos de configuración (no IA):

| Señal | Cómo se detecta |
|---|---|
| Package manager | presencia de `pnpm-lock.yaml` / `package-lock.json` / `yarn.lock` / `bun.lockb` |
| Framework | dependencias en `package.json` + archivos de config (`next.config.*`, `nest-cli.json`, etc.) |
| ORM / base de datos | `prisma/schema.prisma`, `drizzle.config.*`, variables `DATABASE_URL` en `.env.example` |
| Docker | `Dockerfile`, `docker-compose*.yml` |
| Git | existencia de `.git/` |

El resultado es el **Project Snapshot** (tipo `ProjectSnapshot`, ver 02), versionado y regenerable en cualquier momento — nunca se asume válido para siempre.

## Indexer

Construye la tabla `files` (hash + metadata). Para TypeScript/JavaScript (único alcance real en v1, ver 01), extrae imports con un lexer ligero (no un AST completo) y llena `file_edges`. La extracción de `symbols` (funciones/clases/exports reales vía AST) se activa en incremento 2 detrás de una bandera, para no pagar ese costo de parsing en el primer corte.

Reindexado incremental: si `project_state.last_indexed_commit` coincide con el commit actual, no se reescanea nada. Si cambió, `git diff --name-status <last>..HEAD` da la lista exacta de archivos a reindexar. Esto es lo que hace viable usar DevPilot en repos grandes sin re-escanear todo en cada comando — pero, de nuevo, es incremento 2 (ver 07); v1 puede reindexar todo el árbol cada vez sin drama en proyectos de tamaño normal.

## Project Knowledge

Documentos Markdown en `.devpilot/knowledge/`, indexados en `knowledge_docs`. Tres orígenes posibles:

- `manual` — el usuario los edita directamente.
- `inferred` — DevPilot los genera a partir de heurísticas del Scanner (ej. "este proyecto usa Next.js + Prisma + PostgreSQL").
- `deep-analysis` — propuestos por Claude Code vía `analyze --deep` (incremento 3).

Importante: un análisis profundo **nunca sobreescribe silenciosamente** un knowledge doc existente. Propone un diff; el usuario aprueba (es una operación `WRITE`, pasa por el Tool Engine igual que cualquier otra escritura).

## Project State

Lo "efímero pero necesario": último commit indexado, último commit analizado en profundidad, timestamp del último scan. Siempre regenerable, nunca es fuente de verdad del negocio — a diferencia de Knowledge y Decisions, que si se pierden, se pierde conocimiento real.

## Session Memory

Una sesión = una invocación conceptual de trabajo (puede abarcar varios comandos CLI). Se guarda un resumen corto en SQLite (`sessions`) y el detalle turno-a-turno en un `.jsonl` en disco (barato de escribir append-only, no requiere schema rígido). Es memoria de corto plazo: relevante mientras se trabaja en la tarea, candidata a "promoverse" a una Decision Record si algo importante se decidió.

## Decision Records

Formato tipo ADR liviano: título, contexto, decisión, consecuencias, estado. Se crean explícitamente (`devpilot decide "..."`) o DevPilot puede sugerir crear una al cerrar una sesión donde detecta lenguaje de decisión (heurística simple por palabras clave — no obligatorio ni bloqueante). Estas sí son memoria de largo plazo: sobreviven a cualquier sesión futura y se incluyen en el Context Pack cuando son relevantes a la tarea actual.

## Context Planner — niveles progresivos

```
Nivel 1  Búsqueda textual        → keywords de la tarea vs. contenido indexado (ripgrep)
Nivel 2  Grafo de imports         → expande 1-2 saltos desde los archivos del Nivel 1
Nivel 3  Símbolos / AST           → refina: ¿el archivo EXPORTA algo que coincide, o solo lo menciona?  [incremento 2]
Nivel 4  Git / cambios recientes  → boost a archivos tocados recientemente o en commits con mensajes afines [incremento 2]
Nivel 5  Semántico opcional       → la IA re-rankea un candidate set YA acotado (nunca el repo completo) [opcional, apagado por defecto]
```

Cada nivel solo *refina* el conjunto de candidatos del nivel anterior; nunca vuelve a analizar el proyecto entero. El Nivel 5 es explícitamente opt-in porque es el único que cuesta tokens/dinero — todo lo demás es determinístico y gratis.

## Relevance Scoring

Score 0-100 por archivo, suma ponderada y **explicable**:

```
score = w1·textMatch + w2·importDistance + w3·pathNameMatch + w4·gitRecency + w5·symbolMatch
```

Cada score se acompaña de sus `RelevanceReason[]` (ver 02) — el usuario puede ver *por qué* `Pedido.ts` obtuvo 98% y `Usuario.ts` obtuvo 8%, y corregir manualmente agregando/quitando archivos del pack si el algoritmo se equivocó. Los pesos (`w1..w5`) viven en `.devpilot/config.json`, no hardcodeados — se espera iterarlos con uso real.

No se promete precisión perfecta: es un scorer heurístico v1, deliberadamente simple, con un mecanismo de override manual siempre disponible.

## Token Estimation

Aproximación rápida (no se requiere el tokenizer exacto de cada proveedor — proveedores distintos tokenizan distinto, y v1 no necesita esa precisión): estimación tipo `caracteres / 4` o una librería ligera de aproximación BPE. Clasificación configurable:

```
🟢 recomendable   < 4,000 tokens estimados
🟡 alto           4,000–12,000
🔴 innecesariamente grande  > 12,000
```

Umbrales en `config.json`, ajustables por proyecto/proveedor.

## Context Compaction

Estrategias para cuando el pack se pasa de verde/amarillo, en orden de aplicación:

1. Para archivos de score bajo-medio, incluir solo firmas/exports en vez del archivo completo (requiere símbolos — incremento 2; en v1 esto se resuelve simplemente truncando o excluyendo el archivo, con aviso al usuario).
2. Deduplicar conocimiento ya incluido en un pack previo de la misma sesión.
3. Cortar por umbral de relevancia (top-N) en vez de incluir todo lo que superó el Nivel 2.

## Context Pack — construcción final

`ContextPackBuilder` combina: Project Knowledge relevante + Project State resumido + Session Memory relevante + Decision Records relevantes + archivos seleccionados + la tarea del usuario + **instrucciones de formato de respuesta** (el contrato descrito en 01, indispensable para que `devpilot import` funcione después). Esto produce el objeto `ContextPack` (tipo completo en 02), que se serializa a Markdown para copiar/pegar y a JSON para persistencia.
